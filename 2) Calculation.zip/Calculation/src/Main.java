import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        //Выведите сумму сдачи в виде “X рублей и Y копеек”.

        Scanner scr = new Scanner(System.in);
        System.out.print("Стоимость товара: ");
        float rates = scr.nextFloat();
        System.out.print("Взнос за товар: ");
        float quantityOfMoney = scr.nextFloat();
        float change = quantityOfMoney - rates;
        int dollar = (int) (change * 100);
        int count2 = (dollar / 100);
        int count3 = (dollar % 100);
        System.out.println("Сдача: " + count2 + " dollar. " + count3 + " cent.");






    }
}