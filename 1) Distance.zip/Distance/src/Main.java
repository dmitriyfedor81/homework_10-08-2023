import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Дана длина в метрах.
        // Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите длину в метрах: ");
        double metr = scanner.nextDouble();

        double km = metr / 1000;
        double mile = metr / 1609.3;
        double feet = metr * 3.28;
        double arhin = metr / 0.7;

        System.out.println("Длина в километрах: " + km);
        System.out.println("Длина в милях: " + mile);
        System.out.println("Длина в футах: " + feet);
        System.out.println("Длина в аршинах: " + arhin);


    }
}