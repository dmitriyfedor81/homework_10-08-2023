import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут в поход.
        // Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
        // В поход ребят должен кто-то повести.
        // Поведёт тренер Джим, если он освободится от сдачи тренерского экзамена (isJimFree), или тренер Кейт, если она вернётся из путешествия (hasKateComeBack).
        // Вести детей может только один тренер.
        // Если Джим и Кейт смогут вести детей вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.

        Scanner scanner = new Scanner(System.in);

        System.out.print("Учебный год уже закончился? (да/нет): ");
        boolean isYearFinished = scanner.next().equalsIgnoreCase("да");

        System.out.print("На улице солнечно? (да/нет): ");
        boolean isGoodWeather = scanner.next().equalsIgnoreCase("да");

        System.out.print("Позаботился ли туркружок о дождевиках? (да/нет): ");
        boolean hasBoughtRaincoats = scanner.next().equalsIgnoreCase("да");

        System.out.print("Свободен ли тренер Джим от экзамена? (да/нет): ");
        boolean isJimFree = scanner.next().equalsIgnoreCase("да");

        System.out.print("Вернулась ли тренер Кейт из путешествия? (да/нет): ");
        boolean hasKateComeBack =scanner.next().equalsIgnoreCase("да");

       boolean willGoHiking = false;

       if (isYearFinished && isGoodWeather) {
           if (hasBoughtRaincoats || (isJimFree && !hasKateComeBack) || (!isJimFree && hasKateComeBack)) {
               willGoHiking = true;
           }
       }

        System.out.println("Состоится ли поход? " + (willGoHiking ? "да" : "нет"));

       scanner.close();

    }
}